@extends("layouts.app")

@section("content")
@section("title","Our Programs")
@include("partials.page-nav")
@include("partials.page-header",["header_1"=>"Programs","header_2"=>"Our Programs"])

    @if (count($programs) > 10) <!--Events Page Start-->
   <section class="news-page">
    <div class="container">
        <div class="row">
          
                @foreach ($programs as $program)
                   <!--News One Single Start-->
            <div class="col-xl-4 col-lg-6 col-md-6 wow fadeInUp" data-wow-delay="100ms">
                <div class="news-one__single">
                    <div class="news-one__img">
                        <img src="{{ asset('storage/'.$program->image) }}" alt="">
                    </div>
                    <div class="news-one__content-box">
                        <div class="news-one__content-inner">
                            <div class="news-one__content">
                                <ul class="list-unstyled news-one__meta">
                                    <li><a href="{{route("program.detail",$program->id)}}"><i class="far fa-user-circle"></i> Admin</a>
                                    </li>
                                    <li><a href="{{route("program.detail",$program->id)}}"><i class="fas fa-comments"></i> 0
                                            Comments</a>
                                    </li>
                                </ul>
                                <h3 class="news-one__title"><a href="{{route("program.detail",$program->id)}}">{{ $program->title }}</a></h3>
                            </div>
                            <div class="news-one__bottom">
                                <div class="news-one__read-more">
                                    <a href="{{route("program.detail",$program->id)}}"> <span class="icon-right-arrow"></span> Read
                                        More</a>
                                </div>
                                <div class="news-one__share">
                                    <a href="#"><i class="fas fa-share-alt"></i></a>
                                </div>
                            </div>
                            <div class="news-one__social-box">
                                <ul class="list-unstyled news-one__social">
                                    <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                    <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                    {{-- <li><a href="#"><i class="fab fa-dribbble"></i></a></li> --}}
                                </ul>
                            </div>
                        </div>
                        <div class="news-one__date">
                            <p>{{ \Carbon\Carbon::parse($program->created_at)->format('F j, Y') }}</p>
                        </div>
                    </div>
                </div>
            </div>
            <!--News One Single End-->  
                @endforeach
            
           
        </div>
    </div>
</section>
<!--Events Page End-->
@else
@include("partials.notdound",["header"=>"No Program Found."])                
@endif
@endsection
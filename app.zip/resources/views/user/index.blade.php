@extends('layouts.admin')

@section('title')
User
@endsection
@section('content')
<user></user>
@endsection

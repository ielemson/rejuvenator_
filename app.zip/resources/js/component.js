Vue.component('role', require('./components/role.vue').default);

Vue.component('user', require('./components/user.vue').default);

Vue.component('loading', require('./components/loading.vue').default);


<?php $__env->startSection('title'); ?>
Website Settings
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="content">
    <div class="card">
        
        <div class="card-body">
            <div>
                <div>
                    <form method="post" action="<?php echo e(route('website-setting.update', 1)); ?>" enctype="multipart/form-data">
						<?php echo csrf_field(); ?>
						<section class="card-body">
				
							<!-- Tab Menu -->
							<ul class="nav nav-tabs" id="myTab" role="tablist">
								<li class="nav-item">
									<a class="nav-link active" id="website-tab" data-toggle="tab" href="#website" role="tab" aria-controls="website" aria-selected="true">Website Setting</a>
								</li>
								<li class="nav-item">
									<a class="nav-link" id="seo-tab" data-toggle="tab" href="#seo" role="tab" aria-controls="seo" aria-selected="false">SEO Setting</a>
								</li>
								
								<li class="nav-item">
									<a class="nav-link" id="contact-tab" data-toggle="tab" href="#contact" role="tab" aria-controls="contact" aria-selected="false">Contact Setting</a>
								</li>
								<li class="nav-item">
									<a class="nav-link" id="social-tab" data-toggle="tab" href="#social" role="tab" aria-controls="social" aria-selected="false">Social Media</a>
								</li>
							</ul>
							<!-- /Tab Menu -->
							
							<!-- Tab Content -->
							<div class="tab-content" id="myTabContent">
				
								<!-- Website Setting -->
								<div class="tab-pane fade show active" id="website" role="tabpanel" aria-labelledby="website-tab">
									<div class="card">
										<div class="card-header">
											<h5 class="card-title">
												Website Setting
											</h5>
										</div>
										
										<div class="card-body">
																					
											<div class="form-group">
												<label for="website_title" class="required"><?php echo e(__('Website Title')); ?>:</label>
												<input type="text" name="website_title" id="website_title" class="form-control <?php $__errorArgs = ['website_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> form-control-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required="required" value="<?php echo e($setting->website_title); ?>">
				
												<?php $__errorArgs = ['website_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
													<span class="text-danger"><?php echo e($message); ?></span>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
											</div>
											<div class="form-group">
												<label for="work_hours" class="required"><?php echo e(__('Wrok Hours')); ?>:</label>
												<input type="text" name="work_hours" id="work_hours" class="form-control <?php $__errorArgs = ['work_hours'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> form-control-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required="required" value="<?php echo e($setting->work_hours); ?>">
				
												<?php $__errorArgs = ['work_hours'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
													<span class="text-danger"><?php echo e($message); ?></span>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
											</div>
			
											<div class="row">
												<div class="col-md-4">
													<div class="card">
														<div class="card-body text-center">
															<div class="form-group">
																<label for="website_title" class="required"><?php echo e(__('Website Logo')); ?>: Header</label>
																<div class="">
																	<?php if(!empty($setting->website_logo_dark)): ?>
																	<img src="<?php echo e(asset("images/settings/$setting->website_logo_dark")); ?>" alt="..." id="website_logo_dark_output" class="img-thumbnail rounded mb-3"  >
																	<?php else: ?>
																		<img src="" alt="logo" id="website_logo_dark_output" class="img-thumbnail rounded mb-3" >
																	<?php endif; ?>
				
																	<input type="file" class="form-control" name="website_logo_dark">
																	
																</div>
															</div>
														</div>
													</div>
												</div>
												<div class="col-md-4">
													<div class="card">
														<div class="card-body text-center">
															<div class="form-group">
																<label for="website_title" class="required"><?php echo e(__('Website Logo')); ?>: Footer</label>
																<div class="">
																	<?php if(!empty($setting->website_logo_light)): ?>
																	<img src="<?php echo e(asset("images/settings/$setting->website_logo_light")); ?>" alt="..." id="website_logo_dark_output" class="img-thumbnail rounded mb-3"  >
																	<?php else: ?>
																		<img src="" alt="logo" id="website_logo_dark_output" class="img-thumbnail rounded mb-3" >
																	<?php endif; ?>
																	<input type="file" class="form-control" name="website_logo_light">
																	
																</div>
															</div>
														</div>
													</div>
												</div>
												<div class="col-md-4">
													<div class="card">
														<div class="card-body text-center">
															<div class="form-group">
																<label for="website_title" class="required"><?php echo e(__('Website Favicon')); ?>:</label>
																<div class="">
																	<?php if(!empty($setting->website_favicon)): ?>
																	<img src="<?php echo e(asset("images/settings/$setting->website_favicon")); ?>" alt="favicon" id="" class="img-thumbnail rounded mb-3"  >
																	<?php else: ?>
																		<img src="" alt="logo" id="website_logo_dark_output" class="img-thumbnail rounded mb-3" >
																	<?php endif; ?>
				
																	<input type="file" class="form-control" name="website_favicon">
																	
																</div>
															</div>
														</div>
													</div>
												</div>
													
				
											</div> <!-- row-end -->
				
										</div> <!-- card-body-end -->
									</div>
								</div>
								<!-- /Website Setting -->
				
								<!-- SEO Setting -->
								<div class="tab-pane fade" id="seo" role="tabpanel" aria-labelledby="seo-tab">
									<div class="card">
										<div class="card-header">
											<h5 class="card-title">
												SEO Setting
											</h5>
										</div>
										
										<div class="card-body">
													
											<div class="form-group">
												<label for="meta_title"><?php echo e(__('Meta Title')); ?>:</label>
												<input type="text" name="meta_title" id="meta_title" class="form-control <?php $__errorArgs = ['meta_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> form-control-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($setting->meta_title); ?>">
				
												<?php $__errorArgs = ['meta_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
													<span class="text-danger"><?php echo e($message); ?></span>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
											</div>
													
											<div class="form-group">
												<label for="meta_description"><?php echo e(__('Meta Description')); ?>:</label>
												<textarea name="meta_description" id="meta_description" class="form-control <?php $__errorArgs = ['meta_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> form-control-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"><?php echo e($setting->meta_description); ?></textarea> 
				
												<?php $__errorArgs = ['meta_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
													<span class="text-danger"><?php echo e($message); ?></span>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
											</div>
															
											<div class="form-group">
												<label for="meta_tag"><?php echo e(__('Meta Keywords')); ?>:</label>
												<input type="text" name="meta_tag" id="meta_tag" class="form-control <?php $__errorArgs = ['meta_tag'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> form-control-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($setting->meta_tag); ?>">
				
												<?php $__errorArgs = ['meta_tag'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
													<span class="text-danger"><?php echo e($message); ?></span>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
											</div>
				
										</div>
									</div>
								</div>
								<!-- /SEO Setting -->
				
				
								<!-- Contact Setting -->
								<div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="contact-tab">
									<div class="card">
										<div class="card-header">
											<h5 class="card-title">
												Contact Setting
											</h5>
										</div>
										
										<div class="card-body">
														
											<div class="form-group">
												<label for="address"><?php echo e(__('Contact Address')); ?>:</label>
												<textarea name="address" id="address" class="form-control <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> form-control-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"><?php echo e($setting->address); ?></textarea>
				
												<?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
													<span class="text-danger"><?php echo e($message); ?></span>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
											</div>

											<div class="form-group">
												<label for="address"><?php echo e(__('About Us')); ?>:</label>
												<textarea name="about" id="about" class="form-control summernote <?php $__errorArgs = ['about'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> form-control-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" rows="5"><?php echo e($setting->about); ?></textarea>
				
												<?php $__errorArgs = ['about'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
													<span class="text-danger"><?php echo e($message); ?></span>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
											</div>
											<div class="form-group">
												<label for="address"><?php echo e(__('Who We Are')); ?>:</label>
												<textarea name="who_we_are" id="who_we_are" class="form-control summernote <?php $__errorArgs = ['who_we_are'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> form-control-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" rows="5"><?php echo e($setting->who_we_are); ?></textarea>
				
												<?php $__errorArgs = ['who_we_are'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
													<span class="text-danger"><?php echo e($message); ?></span>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
											</div>

												
							
													
											<div class="form-group">
												<label for="phone"><?php echo e(__('Contact Phone')); ?>:</label>
												<input type="text" name="phone" id="phone" class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> form-control-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($setting->phone); ?>">
				
												<?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
													<span class="text-danger"><?php echo e($message); ?></span>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
											</div>
											<div class="form-group">
												<label for="hotline"><?php echo e(__('Hot line')); ?>:</label>
												<input type="text" name="hotline" id="hotline" class="form-control <?php $__errorArgs = ['hotline'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> form-control-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($setting->hotline); ?>">
				
												<?php $__errorArgs = ['hotline'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
													<span class="text-danger"><?php echo e($message); ?></span>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
											</div>
													
											<div class="form-group">
												<label for="email"><?php echo e(__('Contact Email')); ?>:</label>
												<input type="text" name="email" id="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> form-control-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($setting->email); ?>">
				
												<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
													<span class="text-danger"><?php echo e($message); ?></span>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
											</div>
				<div class="row">
					
					<div class="col-md-4">
						<div class="card">
							<div class="card-body text-center">
								<div class="form-group">
									<label for="website_title" class="required"><?php echo e(__('Who We Are Logo')); ?>:</label>
									<div class="">
										<?php if(!empty($setting->who_we_are_img)): ?>
										<img src="<?php echo e(asset("images/settings/$setting->who_we_are_img")); ?>" alt="..." id="website_logo_dark_output" class="img-thumbnail rounded mb-3"  >
										<?php else: ?>
											<img src="" alt="logo" id="website_logo_dark_output" class="img-thumbnail rounded mb-3" >
										<?php endif; ?>

										<input type="file" class="form-control" name="who_we_are_img">
										
									</div>
								</div>
							</div>
						</div>
					</div>

					<div class="col-md-4">
						<div class="card">
							<div class="card-body text-center">
								<div class="form-group">
									<label for="website_title" class="required"><?php echo e(__('About Us Logo')); ?>:</label>
									<div class="">
										<?php if(!empty($setting->about_img)): ?>
										<img src="<?php echo e(asset("images/settings/$setting->about_img")); ?>" alt="..." id="website_logo_dark_output" class="img-thumbnail rounded mb-3"  >
										<?php else: ?>
											<img src="" alt="logo" id="website_logo_dark_output" class="img-thumbnail rounded mb-3" >
										<?php endif; ?>
										<input type="file" class="form-control" name="about_img">
										
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
											
										</div>
									</div>
								</div>
								<!-- Contact Setting -->
				
								<!-- Social Media Setting -->
								<div class="tab-pane fade" id="social" role="tabpanel" aria-labelledby="social-tab">
									<div class="card">
										<div class="card-header">
											<h5 class="card-title">
												Social Media
											</h5>
										</div>
										
										<div class="card-body">
													
											<div class="form-group">
												<label for="facebook"><?php echo e(__('Facebook')); ?>:</label>
												<input type="text" name="facebook" id="facebook" class="form-control <?php $__errorArgs = ['facebook'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> form-control-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($setting->facebook); ?>">
				
												<?php $__errorArgs = ['facebook'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
													<span class="text-danger"><?php echo e($message); ?></span>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
											</div>
													
											<div class="form-group">
												<label for="twitter"><?php echo e(__('Twitter')); ?>:</label>
												<input type="text" name="twitter" id="twitter" class="form-control <?php $__errorArgs = ['twitter'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> form-control-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($setting->twitter); ?>">
				
												<?php $__errorArgs = ['twitter'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
													<span class="text-danger"><?php echo e($message); ?></span>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
											</div>
													
											<div class="form-group">
												<label for="linkedin"><?php echo e(__('Linkedin')); ?>:</label>
												<input type="text" name="linkedin" id="linkedin" class="form-control <?php $__errorArgs = ['linkedin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> form-control-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($setting->linkedin); ?>">
				
												<?php $__errorArgs = ['linkedin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
													<span class="text-danger"><?php echo e($message); ?></span>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
											</div>
													
											<div class="form-group">
												<label for="instagram"><?php echo e(__('Instagram')); ?>:</label>
												<input type="text" name="instagram" id="instagram" class="form-control <?php $__errorArgs = ['instagram'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> form-control-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($setting->instagram); ?>">
				
												<?php $__errorArgs = ['instagram'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
													<span class="text-danger"><?php echo e($message); ?></span>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
											</div>
				
											
				
										</div>
									</div>
								</div>
								<!-- Social Media Setting -->
					<!-- Page Header -->
					<div class="page-header mx-auto">
						<div class="card breadcrumb-card">
							<div>
								
								<div class="col-md-6 p-2 mx-auto">
									<div class="create-btn pull-right">
										<button type="submit" class="btn btn-primary btn-block"><?php echo e(__('Update Settings')); ?></button>
									</div>
								</div>
							</div>
						</div><!-- /card finish -->	
					</div><!-- /Page Header -->
							</div><!-- /Tab Content -->
													
						</section> <!-- /section -->
				
					</form>
                </div>

            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('custom_js'); ?>
    


<link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-lite.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-lite.min.js"></script>
<script>
    $('#summernote').summernote({
        placeholder: 'Please ensure to paste from MS word, Notepad. Avoid pasting directly from other websites.',
        tabsize: 2,
        toolbar: [
            ['style', ['style']],
            ['font', ['bold', 'underline', 'clear']],
            ['color', ['color']],
            ['para', ['ul', 'ol', 'paragraph']],
            ['table', ['table']],
            ['insert', ['link', 'picture', 'video']],
            ['view', ['fullscreen', 'codeview', 'help']]
        ]
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\rejuvenator-update\resources\views/settings/edit.blade.php ENDPATH**/ ?>
<section class="feature-two">
    <div class="container">
        <div class="row">
            <div class="col-xl-6">
                <div class="about-two__left">
                    <div class="about-two__img-box  wow slideInLeft" data-wow-delay="100ms" data-wow-duration="2500ms">
                        <div class="about-two__img">
                            <img src="<?php echo e(asset("images/settings/$setting->who_we_are_img")); ?>" alt="">
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-6">
                <div class="about-two__right">
                    <div class="section-title text-left">
                        <span class="section-title__tagline">The Rejuvenator Initiatives Int'l</span>
                        <h2 class="section-title__title">Who We Are</h2>
                    </div>
                    <?php echo $setting->who_we_are; ?>

                    <a href="<?php echo e(route('about')); ?>" class="thm-btn about-two__btn mt-5">Discover More</a>
                </div>
            </div>
        </div>
    </div>
</section><?php /**PATH C:\laragon\www\rejuvenator-update\resources\views/partials/who_we_are.blade.php ENDPATH**/ ?>


<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title', 'Home'); ?>
<?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="stricky-header stricked-menu main-menu main-menu-two">
    <div class="sticky-header__content"></div><!-- /.sticky-header__content -->
</div><!-- /.stricky-header -->

<!--Main Slider Start-->
<?php echo $__env->make('partials.slider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--Main Slider End-->

<!--Who We are Two Start-->
<?php echo $__env->make("partials.who_we_are", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--Who We are Two Star Two End-->

<!--Vision And Mission One Start-->
<?php echo $__env->make('partials.vision-and-mission', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--Vision And Mission One End-->

<!--Gallery Two Start-->
<?php echo $__env->make('partials.gallery', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--Gallery Two End-->
<!--Project One Start-->

<!--Project One End-->
<!--Feature Two Start-->
<?php echo $__env->make('partials.partners', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--Brand One End-->

<?php $__env->stopSection(); ?>
<?php $__env->startPush("customStyles"); ?>
    <style>
  
.card {
  overflow: hidden;
  background: rgb(238, 174, 202);
  background: radial-gradient(
    circle,
    rgba(238, 174, 202, 1) 0%,
    rgba(148, 187, 233, 1) 100%
  );
  .card-img {
    height: 20rem;
  }
  .card-img-container img {
    object-fit: cover;
    object-position: center;
    max-height: 100%;
    height: 20rem;
  }
  .card-img-overlay {
    color: #fff;
    font-weight: bold;
    text-shadow: 0 0 3px #ff0000, 0 0 5px #0000ff;
  }
}

/* small and extra-small screens */
@media (max-width: 767px) {
  .carousel-inner .carousel-item > div {
    display: none;
    &:first-child {
      display: block;
    }
    .card-img-container img {
      max-width: 100%;
    }
  }
}

/* medium and up screens */
@media (min-width: 768px) {
  .carousel-inner {
    .carousel-item-end.active,
    .carousel-item-next {
      transform: translateX(25%);
    }
    .carousel-item-start.active,
    .carousel-item-prev {
      transform: translateX(-25%);
    }
    .carousel-item.active,
    .carousel-item-next,
    .carousel-item-prev {
      display: flex;
    }
    .carousel-item-end,
    .carousel-item-start {
      transform: translateX(0);
    }
  }
  .card-img-container {
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    img {
      display: inline-block;
      max-height: 100%;
      margin: 0 -50%;
    }
  }
}

    </style>
<?php $__env->stopPush(); ?>


<?php $__env->startPush("customScripts"); ?>
    <script>
        $(document).ready(function () {
  function initCarousel() {
    if ($("#visible").css("display") == "block") {
      $(".carousel .carousel-item").each(function () {
        var i = $(this).next();
        i.length || (i = $(this).siblings(":first")),
          i.children(":first-child").clone().appendTo($(this));

        for (var n = 0; n < 4; n++)
          (i = i.next()).length || (i = $(this).siblings(":first")),
            i.children(":first-child").clone().appendTo($(this));
      });
    }
  }
  $(window).on({
    resize: initCarousel(),
    load: initCarousel()
  });
});

    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\rejuvenator-update\resources\views/welcome.blade.php ENDPATH**/ ?>
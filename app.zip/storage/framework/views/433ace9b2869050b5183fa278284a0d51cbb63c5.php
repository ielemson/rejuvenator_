
<?php $__env->startSection('pageName'); ?>
Create Slider
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card card-primary">
    <div class="card-header">
        <div class="card-tools">
            <a href="<?php echo e(route("sliders.index")); ?>" class="btn btn-danger"><i class="fas fa-shield-alt"></i> See all Sliders</a>
        </div>
    </div>
    <div class="card-body">
        <div class="container mt-5">
            <?php if(session('success')): ?>
                <div class="alert alert-success"><?php echo e(session('success')); ?></div>
            <?php endif; ?>
    
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
    
            <form action="<?php echo e(route('slider.store')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?> 
                
                <div class="form-group">
                    <label for="title">Title 1</label>
                    <input type="text" class="form-control" id="title_1" name="title_1" value="<?php echo e(old("title_1")); ?>" >
                </div>
                <div class="form-group">
                    <label for="title">Title 2</label>
                    <input type="text" class="form-control" id="title_2" name="title_2"  value="<?php echo e(old("title_2")); ?>" >
                </div>
               
                <div class="form-group">
                    <label for="image">Select Image</label>
                    <input type="file" class="form-control" id="image" name="image" required>
                </div>
                <button type="submit" class="btn btn-primary">Upload</button>
            </form>
        </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\rejuvenator-update\resources\views/slider/create.blade.php ENDPATH**/ ?>
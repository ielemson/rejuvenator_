

<?php $__env->startSection('title'); ?>
User
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<user></user>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\lara-roles-permission\resources\views/user/index.blade.php ENDPATH**/ ?>
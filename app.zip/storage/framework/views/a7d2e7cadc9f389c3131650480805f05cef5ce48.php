

<?php $__env->startSection("content"); ?>
<?php $__env->startSection("title","Our Programs"); ?>
<?php echo $__env->make("partials.page-nav", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make("partials.page-header",["header_1"=>"Programs","header_2"=>"Our Programs"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php if(count($programs) > 10): ?> <!--Events Page Start-->
   <section class="news-page">
    <div class="container">
        <div class="row">
          
                <?php $__currentLoopData = $programs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <!--News One Single Start-->
            <div class="col-xl-4 col-lg-6 col-md-6 wow fadeInUp" data-wow-delay="100ms">
                <div class="news-one__single">
                    <div class="news-one__img">
                        <img src="<?php echo e(asset('storage/'.$program->image)); ?>" alt="">
                    </div>
                    <div class="news-one__content-box">
                        <div class="news-one__content-inner">
                            <div class="news-one__content">
                                <ul class="list-unstyled news-one__meta">
                                    <li><a href="<?php echo e(route("program.detail",$program->id)); ?>"><i class="far fa-user-circle"></i> Admin</a>
                                    </li>
                                    <li><a href="<?php echo e(route("program.detail",$program->id)); ?>"><i class="fas fa-comments"></i> 0
                                            Comments</a>
                                    </li>
                                </ul>
                                <h3 class="news-one__title"><a href="<?php echo e(route("program.detail",$program->id)); ?>"><?php echo e($program->title); ?></a></h3>
                            </div>
                            <div class="news-one__bottom">
                                <div class="news-one__read-more">
                                    <a href="<?php echo e(route("program.detail",$program->id)); ?>"> <span class="icon-right-arrow"></span> Read
                                        More</a>
                                </div>
                                <div class="news-one__share">
                                    <a href="#"><i class="fas fa-share-alt"></i></a>
                                </div>
                            </div>
                            <div class="news-one__social-box">
                                <ul class="list-unstyled news-one__social">
                                    <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                    <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                    
                                </ul>
                            </div>
                        </div>
                        <div class="news-one__date">
                            <p><?php echo e(\Carbon\Carbon::parse($program->created_at)->format('F j, Y')); ?></p>
                        </div>
                    </div>
                </div>
            </div>
            <!--News One Single End-->  
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
           
        </div>
    </div>
</section>
<!--Events Page End-->
<?php else: ?>
<?php echo $__env->make("partials.notdound", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>                
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\rejuvenator-update\resources\views/programs.blade.php ENDPATH**/ ?>
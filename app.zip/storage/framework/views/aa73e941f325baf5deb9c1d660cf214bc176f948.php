

<?php $__env->startSection("content"); ?>
<?php $__env->startSection("title","Our Events"); ?>
<?php echo $__env->make("partials.page-nav", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make("partials.page-header",["header_1"=>"Events","header_2"=>"Our Events"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

   <!--Event Details Start-->
   <section class="event-details">
    <div class="container">
        <div class="row">
            <div class="col-xl-8 col-lg-7">
                <div class="event-details__left">
                    <div class="event-details__top">
                        <div class="event-details__date">
                            <p><?php echo e(\Carbon\Carbon::parse($event->created_at)->format('F j, Y')); ?></p>
                        </div>
                        <h3 class="event-details__title" style="color: #283734;">
                            <?php echo e($event->title); ?>

                        </h3>
                       
                    </div>
                    <div class="event-details__img-box">
                        <div class="row">
                            <div class="col-xl-12">
                                <div class="event-details__img-single">
                                    <img src="<?php echo e(asset($event->image)); ?>" alt="">
                                </div>
                            </div>
                            
                        </div>
                    </div>
                    <div class="event-details__bottom">
                        <p class="event-details__text-4" style="text-align:justify">
                         <?php echo $event->description; ?>

                        </p>

                        <div class="event-details__btn-box">
                            <a href="<?php echo e(route("ourevents")); ?>" class="thm-btn event-details__btn">Go Back</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-4 col-lg-5">
                <div class="event-details__right">
                    <div class="event-details__info">
                        <ul class="list-unstyled event-details__info-list">
                            <li>
                                <span>Time:</span>
                                <p><?php echo e(\Carbon\Carbon::parse($event->time)->format('h:s')); ?></p>
                            </li>
                            <li>
                                <span>Date:</span>
                                <p><?php echo e(\Carbon\Carbon::parse($event->time)->format('F j, Y')); ?></p>
                            
                            <li>
                                <span>Location:</span>
                                <p><?php echo e($event->location); ?></p>
                            </li>
                        </ul>
                        <div class="event-details__social">
                            <a href="#"><i class="fab fa-twitter"></i></a>
                            <a href="#"><i class="fab fa-facebook"></i></a>
                            
                            <a href="#"><i class="fab fa-instagram"></i></a>
                        </div>
                    </div>
                  
                </div>
            </div>
        </div>
    </div>
</section>
<!--Event Details End-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\rejuvenator-update\resources\views/event_details.blade.php ENDPATH**/ ?>
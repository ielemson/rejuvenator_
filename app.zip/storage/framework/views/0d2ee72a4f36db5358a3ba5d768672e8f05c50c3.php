

<?php $__env->startSection("content"); ?>
<?php $__env->startSection("title","Our Events"); ?>
<?php echo $__env->make("partials.page-nav", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make("partials.page-header",["header_1"=>"Events","header_2"=>"Our Events"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


  <?php if(count($events) > 0): ?>
   <!--Events Page Start-->
   <section class="events-page">
    <div class="container">
        <div class="row">
          
            <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <div class="col-xl-6 col-lg-6 col-md-6">
                <!--Events One Single Start-->
                <div class="events-one__single">
                    <div class="events-one__img">
                        <img src="<?php echo e(asset($event->image)); ?>" alt="">
                        <div class="events-one__date">
                            <p><?php echo e(\Carbon\Carbon::parse($event->created_at)->format('F j, Y')); ?></p>
                        </div>
                        <div class="events-one__content">
                            <ul class="list-unstyled events-one__meta">
                                <li><i class="fas fa-clock"></i><?php echo e(\Carbon\Carbon::parse($event->time)->format('F j, Y')); ?> - <?php echo e(\Carbon\Carbon::parse($event->time)->format('h:s')); ?></li>
                                <li><i class="fas fa-map-marker-alt"></i><?php echo e($event->location); ?></li>
                            </ul>
                            <h3 class="events-one__title"><a href="<?php echo e(route("oureventsdetails",$event->slug)); ?>"><?php echo e($event->title); ?></a></h3>
                        </div>
                    </div>
                </div>
                <!--Events One Single End-->
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           
          
           
        </div>
    </div>
</section>
<!--Events Page End-->
  <?php else: ?>
 <?php echo $__env->make("partials.notdound",["header"=>"No Event Found."], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <?php endif; ?>
          
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\rejuvenator-update\resources\views/events.blade.php ENDPATH**/ ?>
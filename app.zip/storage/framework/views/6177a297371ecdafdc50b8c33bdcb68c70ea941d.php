
<?php $__env->startSection('pageName'); ?>
Edit Slider
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card card-primary">
    <div class="card-header">
        <div class="card-tools">
            <a href="<?php echo e(route('role.index')); ?>" class="btn btn-danger"><i class="fas fa-shield-alt"></i> See all Roles</a>
        </div>
    </div>
    <div class="card-body">
        <div class="container mt-5">
            <?php if(session('success')): ?>
                <div class="alert alert-success"><?php echo e(session('success')); ?></div>
            <?php endif; ?>
    
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
    
            

            <div class="">
                <form action="<?php echo e(route('sliders.update', $slider->id)); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                   
        
                    <div class="form-group">
                        <label for="title_1">Title 1:</label>
                        <input type="text" name="title_1" id="title_1" class="form-control" value="<?php echo e($slider->title_1); ?>" >
                    </div>
        
                    <div class="form-group">
                        <label for="title_2">Title 2:</label>
                        <input type="text" name="title_2" id="title_2" class="form-control" value="<?php echo e($slider->title_2); ?>" >
                    </div>
        
                    <div class="form-group">
                        <label for="image_path">Current Image:</label>
                        <div>
                            <img src="<?php echo e(asset('storage/images/' . $slider->image_path)); ?>" alt="Current Image" class="image-preview mb-2">
                        </div>
                        <label for="image_path">Change Image:</label>
                        <input type="file" name="image_path" id="image_path" class="form-control" onchange="previewImage(event)">
                    </div>
        
                    <button type="submit" class="btn btn-primary">Update</button>
                </form>
            </div>
        
        </div>
</div>
</div>

<?php $__env->startPush("custom_js"); ?>
<script>
    function previewImage(event) {
        const input = event.target;
        const file = input.files[0];
        const reader = new FileReader();

        reader.onload = function(e) {
            const img = document.createElement('img');
            img.src = e.target.result;
            img.className = 'image-preview';
            const previewDiv = input.previousElementSibling;
            previewDiv.innerHTML = ''; // Clear previous preview
            previewDiv.appendChild(img);
        }

        if (file) {
            reader.readAsDataURL(file);
        }
    }
</script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush("custom_css"); ?>
<style>
    .image-preview {
        max-width: 100%;
        height: auto;
    }
</style>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\rejuvenator-update\resources\views/slider/edit.blade.php ENDPATH**/ ?>
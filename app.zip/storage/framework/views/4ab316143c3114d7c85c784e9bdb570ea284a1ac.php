<?php $__env->startComponent('mail::message'); ?>
# You have a message from <?php echo e($details['name']); ?>


# Subject: <?php echo e($details['subject']); ?> <br>
# Phone: <?php echo e($details['phone']); ?>  <br>
<?php echo e($details['contact']); ?>


<?php $__env->startComponent('mail::button', ['url' => 'https://fmapmedia.com/']); ?>
www.fmapmedia.com
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\laragon\www\rejuvenator-update\resources\views/emails/contactmessage.blade.php ENDPATH**/ ?>
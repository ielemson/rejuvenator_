
<?php $__env->startSection('pageName'); ?>
Create Slider
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1 class="my-4">Sliders</h1>
    <a href="<?php echo e(route('slider.create')); ?>" class="btn btn-primary mb-4">Create New Slider</a>
    <div class="row">
        <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 mb-4">
                <div class="card">
                    <img src="<?php echo e(asset('storage/images/' . $slider->image_path)); ?>" class="card-img-top" alt="<?php echo e($slider->title_1); ?>">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($slider->title_1); ?></h5>
                        <p class="card-text"><?php echo e($slider->title_2); ?></p>
                        <a href="<?php echo e(route('sliders.show', $slider->id)); ?>" class="btn btn-info">View</a>
                        <a href="<?php echo e(route('sliders.edit', $slider->id)); ?>" class="btn btn-warning">Edit</a>
                        <form action="<?php echo e(route('sliders.destroy', $slider->id)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger">Delete</button>
                        </form>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\rejuvenator-update\resources\views/slider/index.blade.php ENDPATH**/ ?>
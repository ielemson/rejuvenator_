

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1 class="my-4">Events</h1>
    <a href="<?php echo e(route("events.create")); ?>" class="btn btn-primary mb-4">Create New Event</a>
    <?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
    <?php endif; ?>

<div class="row">
    <?php $__empty_1 = true; $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="col-md-4 mb-4">
        <div class="card h-100">
            <?php if($event->image): ?>
                <img src="<?php echo e(asset($event->image)); ?>" class="card-img-top" alt="<?php echo e($event->title); ?>">
            <?php endif; ?>
            <div class="card-body">
                <h5 class="card-title"><?php echo e($event->title); ?></h5>
                <p class="card-text"><?php echo e(Str::limit($event->description, 100)); ?></p>
                <p class="card-text"><strong>Status:</strong> <?php echo e(ucfirst($event->status)); ?></p>
                <p class="card-text"><strong>Time:</strong> <?php echo e(\Carbon\Carbon::parse($event->time)->format('F j, Y')); ?></p>
            </div>
            <div class="card-footer d-flex justify-content-between">
                <a href="<?php echo e(route('events.edit', $event->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                <form action="<?php echo e(route('events.destroy', $event->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this event?')">Delete</button>
                </form>
            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div class="col-12">
        <div class="alert alert-info" role="alert">
            No events found. <a href="<?php echo e(route('events.create')); ?>" class="alert-link">Create a new event.</a>
        </div>
    </div>
<?php endif; ?>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\rejuvenator-update\resources\views/events/index.blade.php ENDPATH**/ ?>
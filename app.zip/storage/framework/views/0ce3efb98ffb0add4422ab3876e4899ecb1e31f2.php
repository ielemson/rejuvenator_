

<?php $__env->startSection("content"); ?>
<?php $__env->startSection("title","About Us"); ?>
<?php echo $__env->make("partials.page-nav", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make("partials.page-header",["header_1"=>"About","header_2"=>"About Us"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


       <!--About Four Start-->
       <section class="about-four mb-5">
        <div class="container">
            <div class="row">
                <div class="col-xl-6">
                    <div class="about-four__left">
                        <div class="about-four__img-box">
                            <div class="about-four__img">
                                <img src="<?php echo e(asset("images/settings/$setting->about_img")); ?>" alt="">
                            </div>
                            
                            <div class="about-four__border"></div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-6">
                    <div class="about-four__right">
                        <div class="section-title text-left">
                            <span class="section-title__tagline">About Us</span>
                            <h2 class="section-title__title">Get to know us</h2>
                        </div>
                       <?php echo $setting->about; ?>

                      
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--About Four End-->
    <?php if(count($profiles)>0): ?>
           <!--Team One Start-->
      <section class="team-one">
        <div class="container">
            <div class="row">
              <?php $__currentLoopData = $profiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <!--Team One Single Start-->
                <div class="col-xl-3 col-lg-6 col-md-6 wow fadeInUp" data-wow-delay="100ms">
                    <div class="team-one__single">
                        <div class="team-one__img">
                            <img src="<?php echo e(Storage::url($profile->image)); ?>" alt="">
                            <div class="team-one__social">
                                <a href="#"><i class="fab fa-facebook"></i></a>
                                <a href="#"><i class="fab fa-twitter"></i></a>
                                
                                <a href="#"><i class="fab fa-instagram"></i></a>
                            </div>
                        </div>
                        <div class="team-one__content">
                            <h3 class="team-one__name"><a href="#"><?php echo e($profile->name); ?></a></h3>
                            <p class="team-one__sub-title"><?php echo e($profile->position); ?></p>
                        </div>
                    </div>
                </div>
                <!--Team One Single End-->
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           
            </div>
        </div>
    </section>
    <!--Team One End-->
    <?php endif; ?>
   
     
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\rejuvenator-update\resources\views/about.blade.php ENDPATH**/ ?>